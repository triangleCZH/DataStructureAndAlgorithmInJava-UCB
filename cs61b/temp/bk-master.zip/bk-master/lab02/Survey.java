public class Survey {

    public String getSecretWord() {
        return "Hello is it me you're looking for?";
    }
}
