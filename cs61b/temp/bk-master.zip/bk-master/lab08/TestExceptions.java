public class TestExceptions {

	public static void main (String [ ] args) {
		//________________ ;

		try {
			//________________ ;

		} catch (NullPointerException e) {
			System.out.println ("got null pointer");
		}
		try {
			//________________ ;

		} catch (ArrayStoreException e) {
			System.out.println ("got illegal array store");
		}
		try {
			//________________ ;

		} catch (ClassCastException e) {
			System.out.println ("got illegal class cast");
		}
	}

}
